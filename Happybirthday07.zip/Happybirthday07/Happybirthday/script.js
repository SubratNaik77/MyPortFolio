function myfunction(){
    let x = document.getElementById("demo").value;
    document.getElementById("output").innerHTML="Happy birthday " + x +"🥳🥳";
  
 }